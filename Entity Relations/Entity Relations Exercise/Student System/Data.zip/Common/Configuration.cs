﻿namespace P01_StudentSystem.Common
{
    public class Configuration
    {
        public const string ConnectionString = "Server=.;Database=StudentSystem;Integrated Security=True; Encrypt = false";
    }
}
