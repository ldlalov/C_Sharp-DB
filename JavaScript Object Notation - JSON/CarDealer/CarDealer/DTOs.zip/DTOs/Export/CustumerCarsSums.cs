﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarDealer.DTOs.Export
{
    public class CustumerCarsSums
    {
        public string fullName { get; set; }
        public int boughtCars { get; set; }
        public decimal spentMoney { get; set; }
    }
}
